/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package revmanhalcochranemode;

import java.awt.Component;
import java.io.File;
import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.Comment;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;


/**
 *
 * @author Mercedes Torres Torres
 * Stores a Tree with in specified language
 * 
 */
public class Language {
    
    public Document lang;
    

    public Language(String language, String hal_start, String hal_end, String ack,
             String[] abs1,String[] abs2, String[] abs3, String[] abs4,  String[] abs5,
             String[] abs6, String[] abs7, String[] abs8, String[] abs9, String[] ros1,
             String[] ros2, String[] ros3, String[] ros4, String[] ros5, String[] ros6,
             String[] ros7, String[] eoi1, String[] eoi2, String[] eoi3, String[] eoi4,
             String[] eoi5,String[] eoi6,String[] eoi7,String[] eoi8,String[] eoi9,
             String[] eoi10, String[] eoi11, String[] eoi12,String[] eoi13,String[] eoi14,
             String[] eoi15, String[] eoi16, String[] eoi17,String[] eoi18,String[] eoi19,
             String[] eoi20, String[] eoi21, String[] eoi22,String[] eoi23,String[] eoi24,
             String[] eoi25, String[] eoi26, String[] eoi27,String[] eoi28,String[] eoi29) throws ParserConfigurationException, Exception{       
        
         DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
         DocumentBuilder builder = dbf.newDocumentBuilder();
         lang = builder.newDocument();
      
        // create the root element node
        Element element = lang.createElement("LANGUAGE");
        lang.appendChild(element);
        
        
        //FIRST GENERATION: NAME, HAL_MARKERS, REVIEW, RESULTS OF SEARCH, ABSTRACT
        //Name of Language
        Element name=lang.createElement("NAME");
        name.setAttribute("name", language);
        element.appendChild(name);
     
        Element hal=lang.createElement("HAL_MARKERS");
        hal.setAttribute("start", "----"+hal_start+"----");
        hal.setAttribute("end", "----"+hal_end+"----");
        hal.setAttribute("ack", ack);
        element.appendChild(hal);
        
        //EFFECTS OF INTERVENTION
        Element rev=lang.createElement("REVIEW");
        element.appendChild(rev);
        
        Element intro=lang.createElement("INTRO");
        rev.appendChild(intro); 
        createElement(lang, intro, eoi1, "PAR1");
        createElement(lang, intro, eoi2, "PAR1S");
        createElement(lang, intro, eoi3, "PAR2");
        createElement(lang, intro, eoi4, "PAR2S");
 
        Element comp=lang.createElement("COMPARISON");
        comp.setAttribute("LEVEL", "COMPARISON");
        rev.appendChild(comp);
        
        Element intro2=lang.createElement("INTRO");
        comp.appendChild(intro2);
        createElement(lang, intro2, eoi5, "PAR1");
        createElement(lang, intro2, eoi6, "PAR1S");
   
        Element outcome=lang.createElement("OUTCOME");
        comp.appendChild(outcome);
        
        Element intro3=lang.createElement("INTRO");
        outcome.appendChild(intro3); 
        createElement(lang, intro3, eoi7, "PAR1");
        createElement(lang, intro3, eoi8, "PAR1S");
        createElement(lang, intro3, eoi9, "PAR2");
        createElement(lang, intro3, eoi10, "PAR3");
        createElement(lang, intro3, eoi11, "PAR4");
        
        
        Element other=lang.createElement("OTHER_OUTCOME");
        outcome.appendChild(other);
        createElement(lang, other, eoi12, "PAR1");
        createElement(lang, other, eoi13, "PAR1");
        createElement(lang, other, eoi14, "PAR1");
        createElement(lang, other, eoi15, "PAR1");
        createElement(lang, other, eoi16, "PAR1");
        createElement(lang, other, eoi17, "LINK");
        createElement(lang, other, eoi18, "PAR5");    
        
        Element het=lang.createElement("HETEROGENEITY");
        outcome.appendChild(het);
        
        Element imp=lang.createElement("IMPORTANT");
        het.appendChild(imp); 
        createElement(lang, imp, eoi19, "PAR");
        
        Element mod=lang.createElement("MODERATE");
        het.appendChild(mod); 
        createElement(lang, mod, eoi20, "PAR");
        
        Element ss=lang.createElement("STATISTICAL_SIGNIFICANCE");
        outcome.appendChild(ss);
        
        Element yes=lang.createElement("YES");
        ss.appendChild(yes);
        createElement(lang,yes,eoi21,"PAR");
        
        Element no=lang.createElement("NO");
        ss.appendChild(no);
        createElement(lang,no,eoi22,"PAR");
        
        Element subgroup=lang.createElement("SUBGROUPS");
        outcome.appendChild(subgroup);
        
        Element intro4=lang.createElement("INTRO");
        subgroup.appendChild(intro4);
        createElement(lang, intro4, eoi23, "PAR");
        createElement(lang, intro4, eoi24, "PARSSS");
        createElement(lang, intro4, eoi25, "PAR");


        Element het2=lang.createElement("HETEROGENEITY");
        subgroup.appendChild(het2);
        
        Element imp2=lang.createElement("IMPORTANT");
        het2.appendChild(imp2); 
        createElement(lang, imp2, eoi26, "PAR");
        
        Element mod2=lang.createElement("MODERATE");
        het2.appendChild(mod2); 
        createElement(lang, mod2, eoi27, "PAR");
        
        Element ss2=lang.createElement("STATISTICAL_SIGNIFICANCE");
        subgroup.appendChild(ss2);
        
        Element yes2=lang.createElement("YES");
        ss2.appendChild(yes2);
        createElement(lang,yes2,eoi28,"PAR");
        
        Element no2=lang.createElement("NO");
        ss2.appendChild(no2);
        createElement(lang,no2,eoi29,"PAR");
        
        //RESULTS OF SEARCH
        Element ros=lang.createElement("RESULTS_OF_SEARCH");
        element.appendChild(ros);
        
        createElement(lang, ros, ros1, "PAR1");
        createElement(lang, ros, ros2, "PAR2");
        createElement(lang, ros, ros3, "PAR3");
        createElement(lang, ros, ros4, "PAR4");
        createElement(lang, ros, ros5, "PAR5");
        createElement(lang, ros, ros6, "PAR6");
        createElement(lang, ros, ros7, "PAR7");
       
        
         //ABSTRACT
        Element abs=lang.createElement("ABSTRACT");
        element.appendChild(abs);
        
        createElement(lang, abs, abs1, "ABS_OBJECTIVES");
        createElement(lang, abs, abs2, "ABS_SEARCH_STRATEGY");
        createElement(lang, abs, abs3, "ABS_SELECTION_CRITERIA");
        createElement(lang, abs, abs4, "ABS_DATA_COLLECTION");
        
        Element abs_results=lang.createElement("ABS_RESULTS");
        abs.appendChild(abs_results);
        createElement(lang, abs_results, abs5, "PAR1");
        createElement(lang, abs_results, abs6, "PAR2");
        createElement(lang, abs_results, abs7, "PAR3");
        createElement(lang, abs_results, abs8, "PAR4");
        createElement(lang, abs_results, abs9, "PAR5");
        
          
        Transformer transformer = TransformerFactory.newInstance().newTransformer();
        prettyPrint(lang);
        Source input = new DOMSource(lang);
        //Result output = new StreamResult(new File("C:\\Users\\mczcsg1\\Desktop\\Languages\\"+language+".xml"));
        //transformer.transform(input, output);
        
        Component modalToComponent = null;
        JFileChooser fileChooser = new JFileChooser();

        FileFilter filter1 = new ExtensionFileFilter("XML", new String[] {"xml"});
        fileChooser.setFileFilter(filter1);
        
        fileChooser.setSelectedFile(new File(language));
        
        if (fileChooser.showSaveDialog(modalToComponent) == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile(); 
            file = new File(file.toString() + ".xml");


            Result output = new StreamResult(file);    
            
            transformer.setOutputProperty(OutputKeys.ENCODING, "ISO-8859-1");
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            lang.setXmlStandalone(true);
            transformer.transform(input, output);
        }
  
    }
    
    private void createElement(Document lang, Element element, String[] ros, String par) {
        Element p1=lang.createElement(par);
        for (int i=0;i<ros.length;i++){
            p1.setAttribute("V"+i, ros[i]);
        }
        element.appendChild(p1);  
    }
          
 public Language(File file) throws ParserConfigurationException, SAXException, IOException, XPathExpressionException{
             
    DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
    DocumentBuilder builder = dbf.newDocumentBuilder();
    lang = builder.parse(file);

    lang.getDocumentElement().normalize();

    XPathFactory xpathFactory = XPathFactory.newInstance();
    // XPath to find empty text nodes.
    XPathExpression xpathExp = xpathFactory.newXPath().compile(
            "//text()[normalize-space(.) = '']");  
    NodeList emptyTextNodes = (NodeList) 
            xpathExp.evaluate(lang, XPathConstants.NODESET);

    // Remove each empty text node from document.
    for (int i = 0; i < emptyTextNodes.getLength(); i++) {
        Node emptyTextNode = emptyTextNodes.item(i);
        emptyTextNode.getParentNode().removeChild(emptyTextNode);
    }
            
}
    
  public static final void prettyPrint(Document xml) throws Exception {
        Transformer tf = TransformerFactory.newInstance().newTransformer();
        tf.setOutputProperty(OutputKeys.ENCODING, "ISO-8859-1");
        tf.setOutputProperty(OutputKeys.INDENT, "yes");
        Writer out = new StringWriter();
        tf.transform(new DOMSource(xml), new StreamResult(out));
        System.out.println(out.toString());
    } 
     
    public static void main(String[] args) throws Exception {
      
        //Language test1= new Language();
                
        //prettyPrint(test1.lang);
       
        //Transformer transformer = TransformerFactory.newInstance().newTransformer();
        //Result output = new StreamResult(new File("C:\\Users\\mczcsg1\\Desktop\\Languages\\English.xml"));
        //Source input = new DOMSource(test1.lang);

        //transformer.transform(input, output);
      
    }     

    
    
}
